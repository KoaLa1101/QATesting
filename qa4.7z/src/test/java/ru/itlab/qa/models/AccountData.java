package ru.itlab.qa.models;

import lombok.Data;

@Data


public class AccountData {

    public String username;
    public String password;

}
